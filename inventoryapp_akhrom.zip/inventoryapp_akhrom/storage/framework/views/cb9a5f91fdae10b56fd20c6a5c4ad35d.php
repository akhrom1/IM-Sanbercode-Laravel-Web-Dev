<?php $__env->startSection('title'); ?>
    Detail Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-primary"><?php echo e($category->name); ?></h1>
    <p><?php echo e($category->description); ?></p>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Stock</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->stock); ?></td>
                    <td>
                        <form action="products/<?php echo e($item->id); ?>" method="POST">
                            <a href="/products/<?php echo e($item->id); ?>" class="btn btn-sm btn-info">Detail</a>
                            

                            

                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>

        </tbody>
    </table>
    <a href="/category" class="btn btn-secondary btn-sm ">Kembali</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/category/detail.blade.php ENDPATH**/ ?>