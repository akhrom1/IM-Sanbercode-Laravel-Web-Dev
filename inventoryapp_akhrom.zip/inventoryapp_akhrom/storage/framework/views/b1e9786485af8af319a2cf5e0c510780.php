<?php $__env->startSection('title'); ?>
    Detail Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card border-0 shadow-sm">

        <img src="<?php echo e(asset('images/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="img-fluid rounded-top"
            style="width:100%; height:450px; object-fit:cover;">

        <div class="card-body p-4">

            <h1 class="fw-bold text-primary">
                <?php echo e($product->name); ?>

            </h1>

            <h3 class="text-success fw-bold mb-3">
                Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?>

            </h3>

            <div class="mb-3">
                <span class="badge bg-success">
                    Stock: <?php echo e($product->stock); ?>

                </span>
            </div>

            <hr>

            <h5>Deskripsi Produk</h5>
            <p class="text-muted">
                <?php echo e($product->description); ?>

            </p>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/product/detail.blade.php ENDPATH**/ ?>