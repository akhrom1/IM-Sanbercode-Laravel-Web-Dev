<!doctype html>

<html lang="en">

<head>

<!-- Required meta tags -->

<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Bootstrap CSS -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

<title>Edit Data</title>

</head>

<body>

<h2>Edit Data Game</h2>

//Code disini
<form action="/games/<?php echo e($game->id); ?>" method="POST">
     <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
        <?php endif; ?>
        <?php echo method_field("PUT"); ?>
        <?php echo csrf_field(); ?>
        
        <div>
            <label for="name">Nama Game:</label><br>
            <input type="text" id="name" name="name" value="<?php echo e($game->name); ?>" required>
        </div>
        <br>
        
        <div>
            <label for="gameplay">Gameplay:</label><br>
            <textarea id="gameplay" name="gameplay" rows="4" ><?php echo e($game->gameplay); ?> </textarea>
        </div>
        <br>
        
        <div>
            <label for="developer">Developer:</label><br>
            <input type="text" id="developer" name="developer" value="<?php echo e($game->developer); ?>" >
        </div>
        <br>
        
        <div>
            <label for="year">Tahun Rilis:</label><br>
            <input type="number" id="year" name="year" value="<?php echo e($game->year); ?>">
        </div>
        <br>
        
        <button type="submit">Simpan Data</button>
    </form>



<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

</body>

</html><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/games/edit.blade.php ENDPATH**/ ?>