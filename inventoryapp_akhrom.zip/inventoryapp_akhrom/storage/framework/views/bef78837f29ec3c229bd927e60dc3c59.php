<?php $__env->startSection('title'); ?>
    Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
        <a href="/products/create" class="btn btn-primary mb-4">Tambah Product</a>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <img src="<?php echo e(asset('images/' . $item->image)); ?>" class="card-img-top" alt="<?php echo e($item->name); ?>"
                        style="height: 250px; object-fit: cover;">

                    <div class="card-body">
                        <h5 class="card-title"><?php echo e(Str::limit($item->name, 100)); ?></h5>

                        <span class="badge bg-info text-white"><?php echo e($item->category->name); ?></span>

                        <p class="card-text text-muted">
                            <?php echo e(Str::limit($item->description, 100)); ?>

                        </p>

                        <ul class="list-group list-group-flush mb-3">
                            <li class="list-group-item">
                                <strong>Price:</strong>
                                Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?>

                            </li>
                            <li class="list-group-item">
                                <strong>Stock:</strong>
                                <?php echo e($item->stock); ?>

                            </li>
                        </ul>
                    </div>

                    <div class="card-footer bg-white">
                        <form action="/products/<?php echo e($item->id); ?>" method="POST">
                            <a href="/products/<?php echo e($item->id); ?>" class="btn btn-info btn-sm">
                                Detail
                            </a>

                            <?php if(Auth::check() && Auth::user()->role == 'admin'): ?>
                                <a href="/products/<?php echo e($item->id); ?>/edit" class="btn btn-warning btn-sm">
                                    Edit
                                </a>

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button type="submit" class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">
                                    Delete
                                </button>
                            <?php endif; ?>

                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-warning">
                    Tidak ada Product
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/product/show.blade.php ENDPATH**/ ?>