<?php $__env->startSection('title'); ?>
    Tampil Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <a href="/category/create" class="btn btn-sm btn-primary my-3">Tambah</a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td>
                        <form action="category/<?php echo e($item->id); ?>" method="POST">
                            <a href="/category/<?php echo e($item->id); ?>" class="btn btn-sm btn-info">Detail</a>
                            <a href="/category/<?php echo e($item->id); ?>/edit" class="btn btn-sm btn-warning">Edit</a>

                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="submit" class="btn btn-sm btn-danger" value="Delete" />

                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Tidak ada Categori</td>
                </tr>
            <?php endif; ?>



        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/category/show.blade.php ENDPATH**/ ?>