<?php $__env->startSection('title'); ?>
    Halaman Utama
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="card shadow border-0">
            <div class="card-body p-4">

                <h2 class="fw-bold text-primary mb-3">
                    Selamat Datang, <?php echo e(Auth::user()->name); ?>

                </h2>

                <hr>

                <?php if(!empty($user->age) || !empty($user->bio)): ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <div class="card bg-light border-0">
                                <div class="card-body">
                                    <h6 class="text-secondary">Age</h6>
                                    <h4><?php echo e($user->age ?? '-'); ?></h4>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 mb-3">
                            <div class="card bg-light border-0">
                                <div class="card-body">
                                    <h6 class="text-secondary">Bio</h6>
                                    <p class="mb-0">
                                        <?php echo e($user->bio ?? '-'); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <strong>Profil belum lengkap!</strong><br>
                        Silahkan isi di menu profile
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/dashboard.blade.php ENDPATH**/ ?>