<?php $__env->startSection('title'); ?>
    Tampil Transaction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <a href="/transaction/create" class="btn btn-sm btn-primary my-3">Tambah</a>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nama</th>
                <th scope="col">Nama Product</th>
                <th scope="col">Type</th>
                <th scope="col">Amount</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($item->user->name); ?></td>
                    <td><?php echo e(Str::limit($item->product->name, 150)); ?></td>
                    <td>
                        <?php if($item->type == 'in'): ?>
                            <span class="badge bg-primary">IN</span>
                        <?php elseif($item->type == 'out'): ?>
                            <span class="badge bg-danger">OUT</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($item->amount); ?></td>
                    
                    <td>
                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td>Tidak ada Categori</td>
                </tr>
            <?php endif; ?>



        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/transaction/show.blade.php ENDPATH**/ ?>