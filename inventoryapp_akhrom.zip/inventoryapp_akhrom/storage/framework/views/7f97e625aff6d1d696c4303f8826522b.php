<?php $__env->startSection('title'); ?>
Selamat Datang
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Selamat Datang <?php echo e($first); ?> <?php echo e($last); ?></h1>

<p>Gender: <?php echo e($gender); ?></p>
<p>Nationality: <?php echo e($nationality); ?></p>
<p>Language: <?php echo e(implode(', ', $language)); ?></p>
<p>Bio: <?php echo e($bio); ?></p>
<h2>
    Terima kasih telah bergabung di Sanberbook. Social Media kita bersama!
</h2>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /run/media/akhrom/Data/Git/sanbercode-laravel-batch-77/inventoryapp_akhrom/resources/views/welcome.blade.php ENDPATH**/ ?>